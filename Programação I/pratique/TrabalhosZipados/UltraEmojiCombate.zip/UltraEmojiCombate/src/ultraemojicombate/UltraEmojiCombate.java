/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ultraemojicombate;

public class UltraEmojiCombate {

   
    public static void main(String[] args) {
        Lutador l[] = new Lutador[6];
        l[0] =   new Lutador("Angemydelson", "Brasil", 22, 1.89f, 76, 15,2,5);
        l[0].apresentar();
    }
    
}
