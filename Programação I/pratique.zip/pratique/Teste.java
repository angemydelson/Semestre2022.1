


public class Teste {
    public static void print(){
        MinhaCalculadora.min = 7;
        System.out.println(MinhaCalculadora.min);
        System.out.println(MinhaCalculadora.max);
    }
}
