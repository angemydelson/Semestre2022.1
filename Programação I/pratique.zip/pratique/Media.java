
public class Media {
    public static void main(String[] args){
        System.out.println("Eu sou Angemydelson Saint Bert");
        int A, B=7, C=10,D ;
        A = ler.nextInt();
        
        D = (A+B+C)/3;
        System.out.println("A média é: D");
        if(A<B){
            System.out.println(A);
        } else {
                System.out.println(B);
            }
        
    }


}
    